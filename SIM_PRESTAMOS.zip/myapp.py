
from flask import Flask, jsonify, request
from datetime import timedelta
from restapi.api import api
from config import Config
from flask_cors import CORS

# Iniciar la app de Flask
app =  Flask(__name__)
CORS(app)

app.config.from_object(Config)
app.permanent_session_lifetime = timedelta(days=5) 
    
# Registrar la API
app.register_blueprint(api, url_prefix='/api_sim_prtmo/')

if __name__ == "__main__":
    #app.run(debug=True)
    app.run(debug=True)
