from flask import Flask, jsonify, request, Blueprint, current_app
import numpy as np
import pickle

api = Blueprint('api_sim_prtmo', __name__)

# Cargar el modelo desde el archivo
with open('./modelo_lr.pkl', 'rb') as file:
    modelo = pickle.load(file)

# Hacer que el modelo esté disponible para otros módulos
def get_model():
    return modelo   

@api.route('/predecir', methods=['POST'])
def predecir():    
    # Obtener los datos del cuerpo de la solicitud
    data = request.json
    print(data)
    concedido = data['concedido']
    duracion = data['duracion']
    edad = data['edad']
    tipo_interes = data['tipo_interes']
    estado_laboral = data['estado_laboral']
    tipo_prestamo = data['tipo_prestamo']
        
    # ['CONCEDIDO', 'DURACION_MESES', 'EDAD_CUANDO_CONTRATO', 
    #   'TIPO_INTERES_F', 'TIPO_INTERES_V', 
    #   'DESCR_EST_LAB_INDV_JUBILADO',
    #   'DESCR_EST_LAB_INDV_NO EMPLEADO.DEMANDA EMPLEO',
    #   'DESCR_EST_LAB_INDV_TRABAJADOR CUENTA PROPIA',
    #   'DESCR_EST_LAB_INDV_TRABAJADOR POR CUENTA AJENA',
    #   'TIPO_PRESTAMO_HIPOTECARIO', 'TIPO_PRESTAMO_PERSONAL']
    user_input = []
    # Concecido    
    user_input.append(concedido)
    # Duracion
    user_input.append(duracion)
    # Edad
    user_input.append(edad)

    if tipo_interes == "F":
        user_input.append(1); user_input.append(0)
    elif tipo_interes == "V":
        user_input.append(0); user_input.append(1)

    if estado_laboral=="JUBILADO":
        user_input.append(1); user_input.append(0); user_input.append(0); user_input.append(0) 
    elif estado_laboral=="NO_EMPLEO":
        user_input.append(0); user_input.append(1); user_input.append(0); user_input.append(0) 
    elif estado_laboral=="CUENTA_PROPIA":
        user_input.append(0); user_input.append(0); user_input.append(1); user_input.append(0) 
    elif estado_laboral=="CUENTA_AJENA":
        user_input.append(0); user_input.append(0); user_input.append(0); user_input.append(1)

    if tipo_prestamo == "HIPOTECARIO":
        user_input.append(1); user_input.append(0)
    elif tipo_prestamo == "PERSONAL":
        user_input.append(0); user_input.append(1)

    # Convertir la entrada del usuario a un array numpy y hacer la predicción
    user_input_array = np.array(user_input).reshape(1, -1)
    prediccion = modelo.predict(user_input_array) 
    
    # Devolver la predicción como respuesta JSON
    return jsonify({'prediccion': prediccion.tolist()})
